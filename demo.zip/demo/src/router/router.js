import Main from '@/components/layout/Main';


export default [
    {
        path: '/test',
        component: () => import('@/views/auth/rule/list')
    },
    {
        path: '/',
        component: Main,
        children: [
            {
                path: '/home',
                component: () => import('@/components/HelloWorld')
            },
            {
                path: '/rules/list',
                component: () => import('@/views/auth/rule/list')
            }
        ]
    }]
