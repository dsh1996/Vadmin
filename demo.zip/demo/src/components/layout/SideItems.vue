<template>
  <Aside :style="{width: width+'px', 'background-color': theme}">
    <Section>
      <el-menu
        default-active="2"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        router
      >
        <el-submenu index="1">
          <template slot="title">
            <i class="el-icon-star-off"></i>
            <span>收藏夹</span>
          </template>
          <el-menu-item-group>
            <template slot="title">分组一</template>
            <el-menu-item index="1-1">选项1</el-menu-item>
            <el-menu-item index="1-2">选项2</el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group title="分组2">
            <el-menu-item index="1-3">选项3</el-menu-item>
          </el-menu-item-group>
          <el-submenu index="1-4">
            <template slot="title">选项4</template>
            <el-menu-item index="1-4-1">选项1</el-menu-item>
          </el-submenu>
        </el-submenu>
        <el-submenu index="2">
          <template slot="title">
            <i class="el-icon-setting"></i>
            <span>系统设置</span>
          </template>
          <el-menu-item-group>
            <template slot="title">权限管理</template>
            <el-menu-item index="/rules/list">
              <i class="el-icon-s-help"></i>
              <span>角色管理</span>
            </el-menu-item>
            <el-menu-item index="2-2">
              <i class="el-icon-s-ticket"></i>
              <span>分组管理</span>
            </el-menu-item>
            <el-menu-item index="2-3">
              <i class="el-icon-user-solid"></i>
              <span>人员管理</span>
            </el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group>
            <template slot="title">权限分配</template>
            <el-menu-item index="2-4">
              <i class="el-icon-s-promotion"></i>
              <span>按钮管理</span>
            </el-menu-item>
            <el-menu-item index="2-5">
              <i class="el-icon-s-grid"></i>
              <span>菜单管理</span>
            </el-menu-item>
            <el-menu-item index="2-6">
              <i class="el-icon-s-platform"></i>
              <span>页面管理</span>
            </el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group>
            <template slot="title">系统日志</template>
            <el-menu-item index="1-4">
              <i class="el-icon-s-check"></i>
              <span>授权记录</span>
            </el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-menu-item index="3">
          <i class="el-icon-refrigerator"></i>
          <span slot="title">服务器</span>
        </el-menu-item>
        <el-menu-item index="4">
          <i class="el-icon-help"></i>
          <span slot="title">关于我们</span>
        </el-menu-item>
      </el-menu>
    </Section>
    <slot></slot>
  </Aside>
</template>

<script>
export default {
  props: {
    width: {
      type: Number,
      default: 220
    },
    theme: {
      type: String,
      default: "#99999"
    }
  },
  methods: {
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    }
  }
};
</script>

<style  lang="less" scope>
aside {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  height: 100%;
  & > section {
    width: 100%;
    height: calc(100% - 60px);
    overflow: hidden;
    .el-menu {
      height: 100%;
      border: 0;
      font-size: 14px;
    }
  }
}
</style>