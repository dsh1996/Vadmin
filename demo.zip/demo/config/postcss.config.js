module.exports = {
    plugins: {
      autoprefixer: {}
    }
  }